package com.studyos.app.ui.intro

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.unit.dp
import com.studyos.app.ui.theme.FameGold
import kotlin.math.cos
import kotlin.math.sin

/** Five-point star as a pure vector path (no emoji, no raster). */
fun starPath(center: Offset, outerR: Float, innerR: Float): Path {
    val path = Path()
    val points = 5
    val step = Math.PI / points
    val start = -Math.PI / 2
    for (i in 0 until points * 2) {
        val r = if (i % 2 == 0) outerR else innerR
        val a = start + i * step
        val x = center.x + r * cos(a).toFloat()
        val y = center.y + r * sin(a).toFloat()
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    return path
}

/** Open book silhouette as a vector path. */
fun bookPath(center: Offset, w: Float, h: Float): Path {
    val l = center.x - w / 2f
    val r = center.x + w / 2f
    val t = center.y - h / 2f
    val b = center.y + h / 2f
    val cx = center.x
    val path = Path()
    path.moveTo(l, t + h * 0.25f)
    path.cubicTo(l + w * 0.25f, t + h * 0.02f, cx - w * 0.12f, t + h * 0.02f, cx, t + h * 0.25f)
    path.cubicTo(cx + w * 0.12f, t + h * 0.02f, r - w * 0.25f, t + h * 0.02f, r, t + h * 0.25f)
    path.lineTo(r, b - h * 0.10f)
    path.cubicTo(r - w * 0.25f, b - h * 0.32f, cx + w * 0.12f, b - h * 0.32f, cx, b - h * 0.10f)
    path.cubicTo(cx - w * 0.12f, b - h * 0.32f, l + w * 0.25f, b - h * 0.32f, l, b - h * 0.10f)
    path.close()
    return path
}

/** Center spine line of the book. */
fun bookSpine(center: Offset, h: Float): Path {
    val p = Path()
    p.moveTo(center.x, center.y - h / 2f + h * 0.25f)
    p.lineTo(center.x, center.y + h / 2f - h * 0.10f)
    return p
}

/** Floating gold dust particles behind every intro scene. */
@Composable
fun AmbientParticles() {
    val inf = rememberInfiniteTransition(label = "ambient")
    val t by inf.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Restart),
        label = "drift"
    )
    Canvas(Modifier.fillMaxSize()) {
        for (i in 0 until 14) {
            val fx = (i * 0.073f + 0.05f) % 1f
            val speed = 0.5f + (i % 5) * 0.12f
            val raw = (i * 0.13f + 1f - t * speed) % 1f
            val fy = (raw + 1f) % 1f
            drawCircle(
                color = FameGold.copy(alpha = 0.10f + 0.07f * (i % 4)),
                radius = (2 + (i % 3)).dp.toPx(),
                center = Offset(fx * size.width, fy * size.height)
            )
        }
    }
}

