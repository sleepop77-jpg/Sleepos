package com.studyos.app.ui.theme

import androidx.compose.ui.graphics.Color

val Primary = Color(0xFFD9534F)
val PrimaryDark = Color(0xFFC94440)
val PrimaryDarkNight = Color(0xFF4A2C2C)
val PrimaryLight = Color(0xFFE8706C)
val Surface = Color(0xFFF5E6E5)
val OnPrimary = Color(0xFFFFFFFF)
val OnSurface = Color(0xFF2D2D2D)
val FameGold = Color(0xFFFFD700)
val ShameDark = Color(0xFF8B0000)
val SuccessGreen = Color(0xFF4CAF50)
val WarningRed = Color(0xFFC41C3B)
val AccentTeal = Color(0xFF20B2AA)
val AccentOrange = Color(0xFFF5A623)

