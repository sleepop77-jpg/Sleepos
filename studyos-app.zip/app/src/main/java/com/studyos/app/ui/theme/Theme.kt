package com.studyos.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColors = lightColorScheme(
    primary = Primary,
    onPrimary = OnPrimary,
    primaryContainer = PrimaryLight,
    secondary = AccentOrange,
    tertiary = AccentTeal,
    background = Primary,
    onBackground = OnPrimary,
    surface = Surface,
    onSurface = OnSurface
)

@Composable
fun StudyOSTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColors,
        typography = Typography,
        content = content
    )
}

