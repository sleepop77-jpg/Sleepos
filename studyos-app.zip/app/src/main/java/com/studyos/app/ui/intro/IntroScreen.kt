package com.studyos.app.ui.intro

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.studyos.app.ui.theme.FameGold
import com.studyos.app.ui.theme.OnPrimary
import com.studyos.app.ui.theme.OnSurface
import com.studyos.app.ui.theme.Primary
import com.studyos.app.ui.theme.PrimaryDark
import com.studyos.app.ui.theme.ShameDark
import com.studyos.app.ui.theme.SuccessGreen
import com.studyos.app.ui.theme.Surface
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

/**
 * Website-style intro: logo reveal, then three animated scenes explaining
 * the app (Focus / Fame / Shame), then the Enter gate.
 * The Enter button intentionally does not open anything yet.
 */
@Composable
fun IntroScreen() {
    var phase by remember { mutableIntStateOf(0) }
    var notice by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        delay(1700); phase = 1
        delay(2300); phase = 2
        delay(2300); phase = 3
        delay(2300); phase = 4
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Primary, PrimaryDark)))
    ) {
        AmbientParticles()

        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Crossfade(targetState = phase, animationSpec = tween(600), label = "intro") { p ->
                when (p) {
                    0 -> LogoReveal()
                    1 -> SceneFocus()
                    2 -> SceneFame()
                    3 -> SceneShame()
                    else -> FinalGate(onEnter = { notice = true })
                }
            }
        }

        Box(Modifier.align(Alignment.BottomCenter).padding(20.dp)) {
            AnimatedVisibility(
                visible = notice,
                enter = fadeIn() + slideInVertically { it / 2 }
            ) {
                Box(
                    modifier = Modifier
                        .background(Surface, RoundedCornerShape(14.dp))
                        .padding(horizontal = 18.dp, vertical = 12.dp)
                ) {
                    Text(
                        "Still under construction. This button opens the OS once we add it in the next update.",
                        style = MaterialTheme.typography.bodySmall,
                        color = OnSurface,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
private fun Caption(title: String, body: String) {
    Text(title, style = MaterialTheme.typography.labelLarge, color = FameGold)
    Spacer(Modifier.height(6.dp))
    Text(
        body,
        style = MaterialTheme.typography.bodyLarge,
        color = OnPrimary,
        textAlign = TextAlign.Center,
        modifier = Modifier.padding(horizontal = 36.dp)
    )
}

@Composable
private fun LogoReveal() {
    val ring = remember { Animatable(0f) }
    val fade = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        ring.animateTo(1f, tween(1000, easing = FastOutSlowInEasing))
        fade.animateTo(1f, tween(450))
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(Modifier.size(190.dp)) {
            val side = size.minDimension * 0.92f
            val tl = Offset((size.width - side) / 2f, (size.height - side) / 2f)
            val sz = Size(side, side)
            drawArc(color = OnPrimary.copy(alpha = 0.22f), startAngle = 0f, sweepAngle = 360f, useCenter = false, topLeft = tl, size = sz, style = Stroke(5.dp.toPx()))
            drawArc(color = FameGold, startAngle = -90f, sweepAngle = 360f * ring.value, useCenter = false, topLeft = tl, size = sz, style = Stroke(5.dp.toPx(), StrokeCap.Round))
            val c = Offset(size.width / 2f, size.height / 2f)
            val s = size.minDimension
            drawPath(bookPath(Offset(c.x, c.y + s * 0.08f), s * 0.50f, s * 0.34f), OnPrimary)
            drawPath(bookSpine(Offset(c.x, c.y + s * 0.08f), s * 0.34f), Primary, style = Stroke(3.dp.toPx()))
            drawPath(starPath(Offset(c.x, c.y - s * 0.24f), s * 0.15f, s * 0.06f), FameGold)
        }
        Spacer(Modifier.height(20.dp))
        Text(
            "StudyOS",
            style = MaterialTheme.typography.displayLarge,
            color = OnPrimary,
            modifier = Modifier.alpha(fade.value)
        )
        Text(
            "Your gamified study operating system",
            style = MaterialTheme.typography.bodyLarge,
            color = OnPrimary.copy(alpha = 0.85f),
            modifier = Modifier.alpha(fade.value)
        )
    }
}

@Composable
private fun SceneFocus() {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) { progress.animateTo(1f, tween(1700, easing = LinearEasing)) }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(Modifier.size(170.dp)) {
            val side = size.minDimension * 0.80f
            val tl = Offset((size.width - side) / 2f, (size.height - side) / 2f)
            val sz = Size(side, side)
            val c = Offset(size.width / 2f, size.height / 2f)
            drawArc(color = OnPrimary.copy(alpha = 0.22f), startAngle = 0f, sweepAngle = 360f, useCenter = false, topLeft = tl, size = sz, style = Stroke(9.dp.toPx()))
            drawArc(color = FameGold, startAngle = -90f, sweepAngle = 360f * progress.value, useCenter = false, topLeft = tl, size = sz, style = Stroke(9.dp.toPx(), StrokeCap.Round))
            for (i in 0 until 12) {
                val a = Math.toRadians(i * 30.0)
                val r1 = side / 2f * 0.78f
                val r2 = side / 2f * 0.68f
                drawLine(
                    color = OnPrimary.copy(alpha = 0.5f),
                    start = Offset(c.x + cos(a).toFloat() * r1, c.y + sin(a).toFloat() * r1),
                    end = Offset(c.x + cos(a).toFloat() * r2, c.y + sin(a).toFloat() * r2),
                    strokeWidth = 3.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }
            val ha = Math.toRadians(-90.0 + 360.0 * progress.value)
            drawLine(
                color = OnPrimary,
                start = c,
                end = Offset(c.x + cos(ha).toFloat() * side * 0.30f, c.y + sin(ha).toFloat() * side * 0.30f),
                strokeWidth = 4.dp.toPx(),
                cap = StrokeCap.Round
            )
            drawCircle(color = FameGold, radius = 5.dp.toPx(), center = c)
        }
        Spacer(Modifier.height(22.dp))
        Caption("FOCUS", "Study in timed Pomodoro sprints. The timer is your weapon.")
    }
}

@Composable
private fun SceneFame() {
    val inf = rememberInfiniteTransition(label = "fame")
    val pulse by inf.animateFloat(
        initialValue = 0.92f, targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(650), RepeatMode.Reverse), label = "pulse"
    )
    val rise by inf.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1500, easing = LinearEasing), RepeatMode.Restart), label = "rise"
    )
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(170.dp)) {
                val c = Offset(size.width / 2f, size.height / 2f)
                val s = size.minDimension
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0 + 22.5)
                    val r1 = s * 0.36f
                    val r2 = s * (0.42f + 0.10f * (pulse - 0.92f))
                    drawLine(
                        color = FameGold.copy(alpha = 0.7f),
                        start = Offset(c.x + cos(a).toFloat() * r1, c.y + sin(a).toFloat() * r1),
                        end = Offset(c.x + cos(a).toFloat() * r2, c.y + sin(a).toFloat() * r2),
                        strokeWidth = 4.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
                drawPath(starPath(c, s * 0.30f * pulse, s * 0.13f * pulse), FameGold)
            }
            Text(
                "+2 FAME / MIN",
                style = MaterialTheme.typography.labelLarge,
                color = FameGold,
                modifier = Modifier
                    .offset(y = (-40 - 40 * rise).dp)
                    .alpha(1f - rise)
            )
        }
        Spacer(Modifier.height(18.dp))
        Caption("EARN FAME", "Every study minute pays you. Fame is your currency.")
    }
}

@Composable
private fun SceneShame() {
    val arrow = remember { Animatable(0f) }
    val cancel = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        arrow.animateTo(1f, tween(650, easing = FastOutSlowInEasing))
        delay(150)
        cancel.animateTo(1f, tween(450))
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(Modifier.size(170.dp)) {
            val c = Offset(size.width / 2f, size.height / 2f)
            val s = size.minDimension
            drawCircle(color = OnPrimary.copy(alpha = 0.15f), radius = s * 0.42f)
            val len = s * 0.50f * arrow.value
            val top = c.y - len / 2f
            val bottom = c.y + len / 2f
            drawLine(ShameDark, Offset(c.x, top), Offset(c.x, bottom), 9.dp.toPx(), StrokeCap.Round)
            if (arrow.value > 0.9f) {
                drawLine(ShameDark, Offset(c.x, bottom), Offset(c.x - s * 0.12f, bottom - s * 0.12f), 9.dp.toPx(), StrokeCap.Round)
                drawLine(ShameDark, Offset(c.x, bottom), Offset(c.x + s * 0.12f, bottom - s * 0.12f), 9.dp.toPx(), StrokeCap.Round)
            }
            if (cancel.value > 0f) {
                val d = s * 0.30f * cancel.value
                drawLine(SuccessGreen, Offset(c.x - d, c.y - d), Offset(c.x + d, c.y + d), 8.dp.toPx(), StrokeCap.Round)
                drawLine(SuccessGreen, Offset(c.x - d, c.y + d), Offset(c.x + d, c.y - d), 8.dp.toPx(), StrokeCap.Round)
            }
        }
        Spacer(Modifier.height(22.dp))
        Caption("OUTWORK SHAME", "Skip studying and Shame climbs. Fame cancels it out.")
    }
}

@Composable
private fun FinalGate(onEnter: () -> Unit) {
    val appear = remember { Animatable(0f) }
    LaunchedEffect(Unit) { appear.animateTo(1f, tween(700)) }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier.alpha(appear.value)
    ) {
        Canvas(Modifier.size(120.dp)) {
            val c = Offset(size.width / 2f, size.height / 2f)
            val s = size.minDimension
            drawCircle(color = OnPrimary.copy(alpha = 0.15f), radius = s * 0.48f)
            drawPath(bookPath(Offset(c.x, c.y + s * 0.08f), s * 0.52f, s * 0.34f), OnPrimary)
            drawPath(bookSpine(Offset(c.x, c.y + s * 0.08f), s * 0.34f), Primary, style = Stroke(3.dp.toPx()))
            drawPath(starPath(Offset(c.x, c.y - s * 0.22f), s * 0.16f, s * 0.06f), FameGold)
        }
        Spacer(Modifier.height(14.dp))
        Text("StudyOS", style = MaterialTheme.typography.displayLarge, color = OnPrimary)
        Text(
            "The OS that makes studying addictive",
            style = MaterialTheme.typography.bodyLarge,
            color = OnPrimary.copy(alpha = 0.85f)
        )
        Spacer(Modifier.height(34.dp))
        Box(
            modifier = Modifier
                .clickable { onEnter() }
                .background(OnPrimary, RoundedCornerShape(999.dp))
                .padding(horizontal = 34.dp, vertical = 15.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("ENTER STUDYOS", style = MaterialTheme.typography.labelLarge, color = PrimaryDark)
                Spacer(Modifier.width(10.dp))
                Canvas(Modifier.size(14.dp)) {
                    val p = Path()
                    p.moveTo(size.width * 0.25f, size.height * 0.10f)
                    p.lineTo(size.width * 0.75f, size.height * 0.50f)
                    p.lineTo(size.width * 0.25f, size.height * 0.90f)
                    drawPath(p, PrimaryDark, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Text(
            "v0.1 - intro animation preview",
            style = MaterialTheme.typography.bodySmall,
            color = OnPrimary.copy(alpha = 0.6f)
        )
    }
}

